from distribution import *


def des_max_diff_value():
    """找到 DES 每一个 S-box 的最大值，及其输入和输的出差分值

    :return 由元祖构成的列表，其中每个元祖依次包含最大值，输入和输出的差分值
    """
    max_value = []
    for s, v in des_distribution_all().items():
        v.pop(0)
        plain = [i for j in v for i in j]
        m_value = max(plain)
        row = plain.index(m_value) // 16
        col = plain.index(m_value) % 16
        max_value.append((m_value, row + 1, col))
    return max_value


def aes_or_sm4_max_diff_value(algorithm):
    """找到 AES 或 SM4 S-box 的最大值

    :param algorithm: 加密算法，可以是 AES 或 SM4
    :return 一个元祖，依次包含最大值，输入和输出的差分值
    """
    distribution = aes_or_sm4_distribution(algorithm)
    distribution.pop(0)
    plain = [i for j in distribution for i in j]
    m_value = max(plain)
    row = plain.index(m_value) // 256
    col = plain.index(m_value) % 256
    return m_value, row + 1, col


if __name__ == '__main__':
    print('DES:')
    print(des_max_diff_value())
    print('AES:')
    print(aes_or_sm4_max_diff_value('AES'))
    print('SM4:')
    print(aes_or_sm4_max_diff_value('SM4'))
