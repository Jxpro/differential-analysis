from sbox import *


def des_distribution_single(s_index):
    """计算 DES 单个 S-box 差分分布表

    :param s_index: S-box 的索引
    :return: 差分分布表
    """
    result = [[0] * 16 for _ in range(64)]
    for input_xor in range(64):
        for input_pair1 in range(64):
            input_pair2 = input_pair1 ^ input_xor
            output_pair1 = des_translate(input_pair1, s_index)
            output_pair2 = des_translate(input_pair2, s_index)
            output_xor = output_pair1 ^ output_pair2
            result[input_xor][output_xor] += 1
    return result


def des_distribution_all():
    """计算 DES 所有 S-box 差分分布表"""
    s_boxes = {}
    for s_box in range(8):
        s_boxes.update({'s%d' % (s_box + 1): des_distribution_single(s_box)})
    return s_boxes


def aes_or_sm4_distribution(algorithm):
    """计算 AES 或 SM4 S-box 差分分布表

    :param algorithm: AES 或 SM4 算法
    :return: 差分分布表
    """
    assert algorithm in ['AES', 'SM4'], 'Algorithm must be AES or SM4'
    result = [[0] * 256 for _ in range(256)]
    for input_xor in range(256):
        for input_pair1 in range(256):
            input_pair2 = input_pair1 ^ input_xor
            output_pair1 = aes_or_sm4_translate(input_pair1, algorithm)
            output_pair2 = aes_or_sm4_translate(input_pair2, algorithm)
            output_xor = output_pair1 ^ output_pair2
            result[input_xor][output_xor] += 1
    return result


if __name__ == '__main__':
    # region DES test
    # 输出到文件
    with open('distribution_des.txt', 'w') as f:
        for key, values in des_distribution_all().items():
            f.write(key + ':\n')
            for index, value in enumerate(values):
                f.write("%#04x" % index + ": " + str(value) + '\n')
            f.write('\n')

    # 输出到屏幕
    for key, values in des_distribution_all().items():
        print(key + ':')
        for value in values:
            print([hex(v) for v in value])
        print('')
    # endregion

    # region AES test
    # 输出到文件
    with open('distribution_aes.txt', 'w') as f:
        for key, value in enumerate(aes_or_sm4_distribution('AES')):
            f.write("%#04x" % key + ": " + value.__str__() + '\n\n')

    # 输出到屏幕
    for i in aes_or_sm4_distribution('AES'):
        print(i)
    # endregion

    # region SM4 test
    # 输出到文件
    with open('distribution_sm4.txt', 'w') as f:
        for key, value in enumerate(aes_or_sm4_distribution('SM4')):
            f.write("%#04x" % key + ": " + value.__str__() + '\n\n')

    # 输出到屏幕
    for i in aes_or_sm4_distribution('SM4'):
        print(i)
    # endregion
