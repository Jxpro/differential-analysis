from sbox import des_translate, aes_or_sm4_translate


def des_possible_values(input_xor, output_xor, s_index):
    """计算给定输入和输出差分，给定 DES S-box 下，可能的输入值

    :param input_xor: 输入差分值
    :param output_xor: 输出差分值
    :param s_index: S-box 索引
    :return: 可能的输入值
    """
    possible_values = []
    for input_pair1 in range(64):
        input_pair2 = input_pair1 ^ input_xor
        output_pair1 = des_translate(input_pair1, s_index)
        output_pair2 = des_translate(input_pair2, s_index)
        xor = output_pair1 ^ output_pair2
        if xor == output_xor:
            possible_values.append(input_pair1)
    return possible_values


def aes_or_sm4_possible_values(input_xor, output_xor, algorithm):
    """计算给定输入和输出差分，给定 S-box 下，可能的输入值

    :param input_xor: 输入差分值
    :param output_xor: 输出差分值
    :param algorithm: AES 或 SM4 算法
    :return: 可能的输入值
    """
    possible_values = []
    for input_pair1 in range(256):
        input_pair2 = input_pair1 ^ input_xor
        output_pair1 = aes_or_sm4_translate(input_pair1, algorithm)
        output_pair2 = aes_or_sm4_translate(input_pair2, algorithm)
        xor = output_pair1 ^ output_pair2
        if xor == output_xor:
            possible_values.append(input_pair1)
    return possible_values


if __name__ == '__main__':
    in_xor = int(input("Enter input_xor(hexadecimal): "), 16)
    out_xor = int(input("Enter output_xor(hexadecimal): "), 16)

    # DES
    s = int(input("Enter s_index: "))
    p_values = des_possible_values(in_xor, out_xor, s)

    # AES or SM4
    # algorithm = input("Enter algorithm(AES or SM4): ")
    # p_values = aes_or_sm4_possible_values(in_xor, out_xor, algorithm)

    print([hex(x) for x in p_values])


